package com.pluralsight.dealership;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DealershipApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
